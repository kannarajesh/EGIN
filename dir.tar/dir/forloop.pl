for( $a = 10; $a < 20; $a = $a + 1 ) {
   print "value of a: $a\n";
}
